import React, { useState } from "react";
import { myPost } from "../../Global/myRequest";
import "./FormSignIn.css";
import {toastSuccess,toastError} from "../../Global/myToast";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate , Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLongArrowAltLeft } from '@fortawesome/free-solid-svg-icons'

function FormLogin() {
  const [valueName, setValueName] = useState("");
  const [valuePass, setValuePass] = useState("");
  let navigate = useNavigate();
  const BackHome = (e) =>{
    e.preventDefault();
    navigate("/");
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { userName: valueName, password: valuePass };
    const headers = {
        'Content-Type': 'application/json',
      }
    myPost('Token',headers,data).then((response) => {
      localStorage.setItem('jwtoken', response.jwtoken );
      localStorage.setItem('user', JSON.stringify(response.objAcc));
      if(response.statusRes)
      {
        if(response.objAcc.role === 0)
        {
          navigate('/admin');
          toastSuccess(response.message);
        }else{
          navigate('/');
          toastSuccess(response.message);
        }
      }else{
        toastError(response.message);
      }
    });
  };
  const onChangeValueName = (e) => {
    setValueName(e.target.value);
  };
  const onChangeValuePass = (e) => {
    setValuePass(e.target.value);
  };
  return (
    <div className="sign-in-container">
      <h1 className="title-sign-in">Sign In</h1>
      <form className="sign-in-form" onSubmit={handleSubmit}>
        <div className="field">
          <input
            type="text"
            name=""
            value={valueName}
            onChange={onChangeValueName}
            required
          />
          <span></span>
          <label>Username</label>
        </div>
        <div className="field">
          <input
            type="password"
            name=""
            value={valuePass}
            onChange={onChangeValuePass}
            required
          />
          <span></span>
          <label>Password</label>
        </div>
        {/* <div className="forget_pass">Forget Password</div> */}
        <input
          className="btn_submit"
          type="submit"
          name="login"
          value="Sign In"
        ></input>
        <div className="signup-link">
          <div>
          Not a member ? <Link to='/signup'>Sign Up</Link> 
          </div>
          <button className="btn btn-primary" onClick={BackHome} >
            <FontAwesomeIcon icon={faLongArrowAltLeft} />
          </button>
        </div>
      </form>
    </div>
  );
}
export default FormLogin;

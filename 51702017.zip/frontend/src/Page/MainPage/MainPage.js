import Slide from "../Slide/Slide";
import Categories from "../Categories/Categorie";
import {myGet } from "../../Global/myRequest";
import React, { useState, useEffect } from "react";
function MainPage() {
  const [result, setResult] = useState([]);

  useEffect(() => {
    myGet("Products").then(function (r) {
      setResult(r);
    });
  }, []);
  // const slicedArray = result.slice(0, 4);
  // const slicedArray2 = result.slice(5);

  return (
    <div>
      <Slide />
      <Categories productPros={false} />
      <Categories listPro={result} productPros={true} />
      {/* <Categories listPro={slicedArray2} productPros={true} /> */}
    </div>
  );
}
export default MainPage;

import Card from "./Card";
import srcUser from "../../Image/SVG/account.png";
import srcProduct from "../../Image/gift.png";
import TableList from "./TableList";
import { myGet, myGetWithToken } from "../../Global/myRequest";
import React, { useState, useEffect, useMemo } from "react";
function ContainerAdmin() {
  const [result, setResult] = useState([]);
  const [result1, setResult1] = useState([]);
  let headers = useMemo(() => [], []);
  const token = localStorage.getItem("jwtoken");
  headers = {
    Authorization: `Bearer ${token}`,
  };
  const  GetUser = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("jwtoken");
    headers = {
      Authorization: `Bearer ${token}`,
    };
    setResult1(await myGetWithToken("token", headers));
  };
  useEffect(() => {

    async function test1()
    {
      setResult(await myGet("Products"));
    }
    // async function test2()
    // {
    //   setResult1(await myGetWithToken("token", headers));
    // }

    test1();
    return () => {};
  });
  localStorage.setItem("productID", `PR${result.length + 1}`);
  return (
    <div className="contrainer container-fluid">
      <div className="container-1 container-fluid">
        <div className="row">
          <Card src={srcUser} nametag={"Người Dùng"} count={result1.length} />
          <Card src={srcProduct} nametag={"Sản Phẩm"} count={result.length} />
        </div>
      </div>
      <button className="btn btn-add-product btn-primary" onClick={GetUser}>
        Lấy Người Dùng
      </button>
      <br />
      {/* <button className="btn btn-add-product btn-primary" onClick={GetProduct}>
        Lấy Danh sách Sản Phẩm
      </button> */}
      <TableList listPro={result} listUser={result1} />
    </div>
  );
}
export default ContainerAdmin;

import TableProduct from "./TableProduct";
import TableUser  from "./TableUser";
import AddProduct from "./formAddProduct/AddProduct";
function TableList(props)
{
    return(
        <div className="content-2">
            <AddProduct/>
            <TableProduct listPro={props.listPro}/>
            <TableUser listUser={props.listUser}/>
        </div>
    )
}
export default TableList;
import { useNavigate } from "react-router-dom";
import {useEffect} from "react";
function CellProduct(props)
{
    useEffect(()=>{

    },[])
    const products = props.items;
    let navigate = useNavigate();
    function handleClick() {
        navigate(`/product/${products.productID}`);
    };
    return(
        <div className="col-4-pro" onClick={handleClick}>
            <img className="img-theme" src={products.image} alt="img-pro"></img>
            <h6>{products.productID} - {products.nameProduct}</h6>
            <p>{products.prices}</p>
        </div>
    )
}
export default CellProduct;
// // import InfoPro from "./CartProduct";
import React, { useEffect } from "react";
// import pro from "../../Image/product5.jpg";
import { myDelete } from "../../Global/myRequest";
import { toastSuccess, toastError } from "../../Global/myToast";
function Table(props) {
  useEffect(() => {
    return () => {
      // This is the cleanup function
    }
  }, []);
  const list = props.listOrder;
  const DeleteProduct = (e) => {
    const token = localStorage.getItem("jwtoken");
    const orderId = localStorage.getItem("orderID");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    // console.log(e, orderId, headers);
    myDelete(`Order/${orderId}/product/${e}`, headers).then((response) => {
      if (response.statusRes === true) {
        toastSuccess(response.message);
      } else {
        toastError(response.message);
      }
    });
  };
  return (
    <table className="table-Order">
      <thead>
        <tr>
          <th>Sản Phẩm</th>
          <th>Số Lượng</th>
          <th>Thành Tiền</th>
          <th>Tác Vụ</th>
        </tr>
      </thead>

      <tbody>
        {list.map((items, i) => {
          return (
            <tr key={i}>
              <td>
                <div className="cart-infor">
                  <img
                    className="cart-info-img"
                    src={items.image}
                    alt="img-pro"
                  />
                  <div>
                    <p>
                      {items.productId} - {items.nameProduct}
                    </p>
                    <p>Pices: {items.prices} VND</p>
                  </div>
                </div>
              </td>
              <td>
                <input
                  className="product-quantity"
                  type="number"
                  disabled="disabled"
                  value={items.countProduct}
                  name="quantity"
                />
              </td>
              <td>Prices: {items.countProduct * items.prices }</td>
              <td>
                  <button
                    type="button"
                    onClick={() => DeleteProduct(items.productId)}
                    className="btn btn-danger btn-delete-product"
                  >
                    Delete
                  </button>
                </td>
            </tr>
          );
        })}
      </tbody>

      <tfoot></tfoot>
    </table>
  );
}
export default Table;

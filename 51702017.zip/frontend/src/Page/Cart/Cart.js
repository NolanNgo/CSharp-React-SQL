// import Table from "./Table";
// import TotalPrices from "./TotalPrices";
import "./Cart.css";
import React, { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { myGetWithToken } from "../../Global/myRequest";
import { useNavigate } from "react-router-dom";
import { useReactToPrint } from 'react-to-print';
import { ComponentToPrint } from './Payment';

function Cart() {
  let navigate = useNavigate();
  const params = useParams();
  const componentRef = useRef(null);
  const [listOrders, setListOrders] = useState([]);
  const [totalprice, setTotalPrice] = useState(0);
  //   const [totalPrices, setTotalPrices] = useState(0);
  const orderID = params.id;

  useEffect(() => {
    const token = localStorage.getItem("jwtoken");
    const headers = {
      Authorization: `Bearer ${token}`,
    };
    if (token === null ) {
      navigate("/signin");
    } else {
      myGetWithToken(`Order/orderID/${orderID}`, headers).then(function (
        response
      ) {
        setListOrders(response);
      });
      const totalprice = () =>{
        let sum = 0;
        listOrders.map((items, i)=>(sum += items.countProduct * items.prices))
        setTotalPrice(sum);
      }
      totalprice()
    }

    // //https://localhost:44359/api/Order/orderID/HD001
  }, [orderID, navigate, listOrders]);
  const SubmitOrder  = useReactToPrint({
    content: () => componentRef.current,
    onAfterPrint: ()  =>{
      localStorage.removeItem("orderID");
    },
  });
  return (
    <div className="cart-container">
      <ComponentToPrint  orderID={orderID} listOrders={listOrders} total={totalprice}  ref={componentRef} />
      <button className="btn btn-primary" onClick={SubmitOrder}>Thanh Toán</button>
    </div>
  );
}

/* <Table listOrder={listOrders} />
<TotalPrices total={totalprice} /> */
export default Cart;

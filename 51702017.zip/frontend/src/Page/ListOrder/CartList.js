import {useEffect} from "react";
function Table(props) {
  useEffect(() => {
    return () => {
      // This is the cleanup function
    }
  }, []);
    const list = props.listOrder;
    return (
      <table className="table-Order">
        <thead>
          <tr>
            <th>{props.titleOrder}/Sản Phẩm</th>
            <th>Số Lượng</th>
            <th>Thành Tiền</th>
          </tr>
        </thead>
  
        <tbody>
          {list.map((items, i) => {
            return (
              <tr key={i}>
                <td>
                  <div className="cart-infor">
                    <img
                      className="cart-info-img"
                      src={items.image}
                      alt="img-pro"
                    />
                    <div>
                      <p>
                        {items.productId} - {items.nameProduct}
                      </p>
                      <p>Pices: {items.prices} VND</p>
                    </div>
                  </div>
                </td>
                <td>
                  <input
                    className="product-quantity"
                    type="number"
                    disabled="disabled"
                    value={items.countProduct}
                    name="quantity"
                  />
                </td>
                <td>Prices: {items.countProduct * items.prices}</td>
              </tr>
            );
          })}
        </tbody>
  
        <tfoot></tfoot>
      </table>
    );
  }
  export default Table;
  
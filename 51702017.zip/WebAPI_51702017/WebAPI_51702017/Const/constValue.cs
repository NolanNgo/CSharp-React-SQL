﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI_51702017.Const
{
    public class constValue
    {
        public static string ConnectionString = "Data Source =DESKTOP-0TNSCDG\\SQLEXPRESS;Database=Project51702017; Trusted_Connection=True ";
    }
}
